﻿# Part 06 - Customer Frontend

## Goal
Show customer-side architecture and reusable UI design.

## Code Areas
- `frontend/src/App.jsx`
- `frontend/src/context/ShopContext.jsx`
- `frontend/src/components/Navbar.jsx`
- `frontend/src/components/Footer.jsx`
- `frontend/src/components/ProductItem.jsx`
- `frontend/src/pages/Home.jsx`
- `frontend/src/pages/Collection.jsx`
- `frontend/src/pages/Product.jsx`
- `frontend/src/pages/Login.jsx`

## What To Explain
- Route-driven customer pages.
- Shared state via context.
- Reusable components and product rendering flow.

## Demo Checklist
1. Show central routes from `App.jsx`.
2. Explain state/actions from `ShopContext.jsx`.
3. Open key components and show reusability pattern.
