﻿# Part 04 - Product and Media Flow

## Goal
Show product management and image upload pipeline.

## Code Areas
- `backend/controllers/productController.js`
- `backend/routes/productRoute.js`
- `backend/middleware/multer.js`
- `backend/config/cloudinary.js`
- `admin/src/pages/Add.jsx`
- `admin/src/pages/List.jsx`

## What To Explain
- Product create/list/update/remove flow.
- Image upload handling with Multer + Cloudinary.
- Admin UI for adding and listing products.

## Demo Checklist
1. Show product endpoints in `productRoute.js`.
2. Show upload middleware in `multer.js`.
3. Run admin and create a product from `Add.jsx` screen.
4. Verify product appears in `List.jsx`.
