﻿# Part 07 - Admin Panel

## Goal
Show admin-specific workflow and protected operations.

## Code Areas
- `admin/src/App.jsx`
- `admin/src/components/Login.jsx`
- `admin/src/components/Navbar.jsx`
- `admin/src/components/Sidebar.jsx`
- `admin/src/pages/Add.jsx`
- `admin/src/pages/List.jsx`
- `admin/src/pages/Orders.jsx`

## What To Explain
- Admin token login handling.
- Page-level operations for product and order management.
- Clean separation between customer and admin UI apps.

## Demo Checklist
1. Open admin `App.jsx` and explain token-based rendering.
2. Show sidebar navigation.
3. Demo add/list/orders screens.
