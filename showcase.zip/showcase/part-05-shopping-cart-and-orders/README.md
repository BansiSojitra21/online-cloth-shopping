﻿# Part 05 - Shopping Cart and Orders

## Goal
Show user purchase journey from cart to order.

## Code Areas
- `backend/controllers/cartController.js`
- `backend/routes/cartRoute.js`
- `backend/controllers/orderController.js`
- `backend/routes/orderRoute.js`
- `frontend/src/pages/Cart.jsx`
- `frontend/src/pages/PlaceOrder.jsx`
- `frontend/src/pages/Orders.jsx`
- `frontend/src/pages/Verify.jsx`

## What To Explain
- Cart add/update/get flow.
- Order placement and order history flow.
- Payment verification screen path.

## Demo Checklist
1. Show cart and order APIs from route files.
2. Open cart/order controllers for business flow.
3. Run frontend and complete add-to-cart to place-order journey.
