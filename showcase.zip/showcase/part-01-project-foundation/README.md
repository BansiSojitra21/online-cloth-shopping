﻿# Part 01 - Project Foundation

## Goal
Show how the project is structured as a full-stack system.

## Code Areas
- `backend/server.js`
- `frontend/src/main.jsx`
- `frontend/src/App.jsx`
- `admin/src/main.jsx`
- `admin/src/App.jsx`
- `start-local.ps1`

## What To Explain
- Three apps: backend API, customer frontend, admin frontend.
- Route-level structure in customer and admin apps.
- Local startup flow using script.

## Demo Checklist
1. Show root folders: `backend`, `frontend`, `admin`.
2. Open `backend/server.js` and explain API mounts.
3. Open `frontend/src/App.jsx` and show page routes.
4. Open `admin/src/App.jsx` and show admin routes.
