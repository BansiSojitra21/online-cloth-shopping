﻿# Part 08 - Integration, Testing, and Delivery

## Goal
Show full-system readiness for demo and handover.

## Code Areas
- `start-local.ps1`
- `guide.txt`
- `backend/vercel.json`
- `frontend/vite.config.js`
- `admin/vite.config.js`

## What To Explain
- End-to-end startup process.
- Environment and run instructions.
- Deployment-aware configuration files.

## Demo Checklist
1. Run startup scripts/commands.
2. Hit frontend, backend, and admin URLs.
3. Show test credentials from `guide.txt`.
4. Explain delivery instructions for evaluator.
