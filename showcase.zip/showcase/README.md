﻿# 8-Part Code Progress Showcase

Use these folders to present your progress part-by-part.

Presentation order:
1. `part-01-project-foundation`
2. `part-02-backend-core-setup`
3. `part-03-data-models-and-auth`
4. `part-04-product-and-media-flow`
5. `part-05-shopping-cart-and-orders`
6. `part-06-customer-frontend`
7. `part-07-admin-panel`
8. `part-08-integration-testing-and-delivery`

Quick demo flow:
1. Open each part's `README.md`.
2. Open the listed source files.
3. Run the demo checklist of that part.

Tip:
Use this command from project root to run backend:
`cd backend; npm run server`

Use this command for customer frontend:
`cd frontend; npm run dev`

Use this command for admin panel:
`cd admin; npm run dev -- --host 127.0.0.1 --port 5175`
