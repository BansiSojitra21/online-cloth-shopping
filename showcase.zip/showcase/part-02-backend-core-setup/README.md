﻿# Part 02 - Backend Core Setup

## Goal
Show backend environment, server bootstrap, and route wiring.

## Code Areas
- `backend/server.js`
- `backend/config/mongodb.js`
- `backend/config/cloudinary.js`
- `backend/routes/userRoute.js`
- `backend/routes/productRoute.js`
- `backend/routes/cartRoute.js`
- `backend/routes/orderRoute.js`

## What To Explain
- Express app initialization and middleware.
- Database and Cloudinary connections.
- API modules split by feature route.

## Demo Checklist
1. Show `app.use('/api/...')` mapping in `server.js`.
2. Open `config` files and explain external service setup.
3. Open each route file and show endpoint grouping.
