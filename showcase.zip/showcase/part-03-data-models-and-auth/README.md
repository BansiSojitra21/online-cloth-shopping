﻿# Part 03 - Data Models and Auth

## Goal
Show data layer and security flow.

## Code Areas
- `backend/models/userModel.js`
- `backend/models/productModel.js`
- `backend/models/orderModel.js`
- `backend/middleware/auth.js`
- `backend/middleware/adminAuth.js`
- `backend/controllers/userController.js`

## What To Explain
- MongoDB models for user, product, and order.
- Token-based middleware for user/admin protection.
- User login/register controller logic.

## Demo Checklist
1. Open model files and show schema fields.
2. Open auth middlewares and explain token check.
3. Open user controller and show auth-related functions.
